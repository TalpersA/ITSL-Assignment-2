#9a. Quantitative - mpg, displacement, HP, weight, and acceleration.  
#9a. Qualitative - origin, name
#9b. Ranges - MPG = 37.6, cylinder = 3, displacement = 387, HP = 184, weight = 3527, acceleration = 16.8, year = 12
#9c. MPG: mean = 23.45, standard deviation = 7.81
#9c. Cylinders: mean = 5.47, standard deviation = 1.71
#9c. Displacement: mean = 194.41, standard deviation = 104.64
#9c. HP: mean = 104.47, standard deviation = 38.49
#9c. Weight: mean = 2977.58, standard deviation = 849.40
#9c. Acceleration: mean = 15.54, standard deviation = 2.76
#9c. Year: mean = 75.98, standard deviation = 3.68
#9d. MPG: mean = 35.6, standard deviation = 7.87
#9d. Cylinders: range = 5, mean = 5.37, standard deviation = 1.65
#9d. Displacement: range = 387, mean = 187.24, standard deviation = 99.68
#9d. HP: range = 184, mean = 100.72, standard deviation = 35.71
#9d. Weight: range = 3348, mean = 2935.97, standard deviation = 811.30
#9d. Acceleration: range = 16.3, mean = 15.73, standard deviation = 2.69
#9d. Year: mean = 77.15, standard deviation = 3.11
#9e. Cars in the observed data set show increased efficiency with newer model year.
#9e. Heavier cars tend to get worse gas mileage.
#9e. A higher number of cylinders tends to relate to worse gas mileage. 
#9f. 9e shows how three variables can be used in predicting the value of MPG.
#9f. All predictors demonstrate some degree of correlation, name is probably the least reliable.