#10a. 506 rows, 14 columns.  Rows (I think) represent a designated land tract within the city.  Columns are for various values pertaining to area demographics.\
#10b. Crime correlates with age, dis, rad, tax, and ptratio.  Nox correlates with age and dis.
#10c. Crime - crime tends to correlate with home age, IE more crime in areas with odler homes.
#10c. Similarly increased crime correlates with increased tax rates and in areas in which schools have a higher student:faculty ratio.
#10d. A crime rate >95% is found in 16 suburbs of the given dataset, and some suburbs are plagued with an incredibly high crime rate.
#10d. Property taxes are relatively consistent throughout, with no single suburb having a tax rate 2 standard deviations from the mean value.
#10d. No suburbs show an extremely high student:teacher ratio.
#10e. 35 
#10f. 19.05
#10g. Tracts 399 and 406 have the lowest median home values.  Both exhibit high crime rates. Most of the predictors are very close in value, a few are even identical.
#10h. 64, 13.  Homes with >8 rooms tend to be in areas with lower crimes rates.