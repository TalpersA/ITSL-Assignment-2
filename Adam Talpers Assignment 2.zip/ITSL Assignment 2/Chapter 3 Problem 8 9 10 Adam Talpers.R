#8ai. Data suggests a relationship between MPG and HP - HP p-value coefficient is near 0.
#8aii. Strong. 
#8aiii. Negative.
#8aiv. ~24.5mpg.  Prediction intervals (fit, lwr, upr) = 24.46708 14.8094 34.12476, confidence intervals (fit, lwr, upr) = 1 24.46708 23.97308 24.96108.
#8c.  Residual vs Fitted plot suggests the dataset is nonlinear. 
#8c.  Residual vs Leverage suggests that high leverage is seen is some observations.
#8c. Possible outliers are shown on Scale-Location. 

#9ci. There's strong evidence for a relationship between predictor and response. 
#9cii. Weight, year, origin, and displacement.
#9ciii. A coefficient value of 0.75 means that for each increase in year is associated with a predicted 0.75 increase in MPG.  This assumes all other predictors are held constant.
#9d. There are some potential outliers in our data.  Nonlinearity is demonstrated in our Residual vs Fitted plot.  Observation 14 is shown to have high leverage in Residuals vs Leverage plot.
#9e. Statistical significance is demonstrated in cylinders:year and HP:acceleration.
#9f. An increase in R^2 coefficient is observed in both mpg_poly and mpg_poly2.

#10b. Negative price coefficient - this means that for every $1 increase in price, sales are expected to drop by ~54 seats.
#10b. Urban=Yes is not statistically significant.
#10b. US=Yes suggests an increase of ~1200 in car seat sales when US=Yes (assuming this means a US marketplace)
#10b. Average number of car seats sold when all other predictors are held constant is shown at the intercept.
#10c. Sales = 13.04 + -0.05 Price + -0.02 UrbanYes + 1.20 USYes
#10d. Can reject the null hypothesis for - Advertising, Age, CompPrice, Price, Shelvelocgood, Shelvelocmedium, and Income.
#10f. Both models form a relatively similar fit, but model e forms a better fit with the data.
#10h. Some outliers exist in addition to one high leverage observation. Overall the Residuals vs Fitted plot shows a decent fit for the data.