# Data shows that a higher graduation rate is often correlated with higher tuition.
# Lower Student to Faculty ratios are observed in colleges with lower acceptance rates.
